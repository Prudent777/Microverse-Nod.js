require('http').createServer(function(req, res) {
  res.end('Hello world!');
}).listen(9000);